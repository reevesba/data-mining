/*
 * Implement elements of Data Mining with First
 * Order Logic (FOL) in two languages.
 * 
 * Program a FOL expression A(x, y, z) => R(x, y, z) in two forms:
 * * A(x,y,z) is true if (H(x)>H(y)>H(z)) is true & (W(x)>W(y)>W(z)) is true
 * * A(x, y, z) is (H(x, y) & H(y, z) & W(x,y) & W(y, z))
 * * R(x, y, z) is (N(x) & N(z) & N(y))
 * for 4 objects a, b, c, and d with H, W, and N values entered
 * randomly by a user.
 * 
 * Output a confusion matrix for A => R
 * 
 * Algorithm:
 * 1. Assign x = a, y = b, z = c and compute A(x, y, z) and R(x, y, z) for them.
 * 2. Next, change the assignment x = a, y = b,  z = d and compute these predicates for them.
 * 3. Continue process until all triples of four elements a, b, c and d are explored.
 * 4. Summarize result in the confusion matrix.
 *
 */
package fol;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author REEVESBRA
 */
public class FOL {
    
    private static String[][] loadData(String fileName) throws FileNotFoundException, IOException {
        List<String[]> rows = new ArrayList<>();
        String row;
        
        FileInputStream csv = new FileInputStream(fileName);
        DataInputStream in = new DataInputStream(csv);
        
        while ((row = in.readLine()) != null)
            rows.add(row.split(","));
        
        String[][] dataset = new String[rows.size()][0];
        rows.toArray(dataset);
        
        return dataset;
    }
        
    private static String[][] removeHeaders(String[][] arr) {
        String[][] dataset = new String[arr.length - 1][arr[0].length];
        
        for (int i = 0; i < arr.length - 1; i++)
            System.arraycopy(arr[i + 1], 0, dataset[i], 0, arr[i].length);
        
        return dataset;
    }
    
    private static double[][] toDouble(String[][] arr) {
        double[][] dataset = new double[arr.length][arr[0].length];
        
        for (int i = 0; i < arr.length; i++)
            for (int j = 0; j < arr[i].length; j++)
                dataset[i][j] = Double.parseDouble(arr[i][j]);

        return dataset;
    }
    
    private static void printArray(Integer[] arr) {
        System.out.print("[");
        for (int i = 0; i < arr.length; i++)
            if (i < arr.length - 1) System.out.print(arr[i] + ", ");
            else System.out.println(arr[i] + "]");
    }
    
        private static void printMetrics(double[] metrics) {
        String f = "%.2f";
        System.out.println("Accuracy: " + String.format(f , metrics[0]) + "%");
        System.out.println("Recall: " + String.format(f , metrics[1]) + "%");
        System.out.println("False Positive Rate: " + String.format(f , metrics[2]) + "%");
        System.out.println("True Negative Rate: " + String.format(f , metrics[3]) + "%");
        System.out.println("False Negative Rate: " + String.format(f , metrics[4]) + "%");
        System.out.println("Precision: " + String.format(f , metrics[5]) + "%");
    }
    
    private static double[] metrics(int[] matrix){
        double[] metrics = new double[6];
        double a = matrix[0], b = matrix[1], c = matrix[2], d = matrix[3];
        
        metrics[0] = (a + d)/(a + b + c + d)*100.00;   // acc
        metrics[1] = d/(c + d)*100.00;                 // recall
        metrics[2] = b/(a + b)*100.00;                 // FP rate
        metrics[3] = a/(a + b)*100.00;                 // TN rate
        metrics[4] = c/(c + d)*100.00;                 // FN rate
        metrics[5] = d/(b + d)*100.00;                 // precision
       
        return metrics;
    }
    
    private static void printMatrix(int[] matrix) {
        System.out.println("Confusion Matrix:");
        System.out.println(" _____________________________________________________");
        System.out.println("|                         |_________Predicted_________|");
        System.out.println("|_________________________|___Negative__|__Positive___|");
        System.out.println(String.format("| Actual |____Negative____|_____%3d_____|_____%3d_____|", matrix[0], matrix[1]));
        System.out.println(String.format("|________|____Positive____|_____%3d_____|_____%3d_____|\n", matrix[2], matrix[3]));
    }
    
    private static int[] confusionMatrix(double[] targets, double[] predictions){
        int a = 0, b = 0, c = 0, d = 0;
        
        for (int i = 0; i < targets.length; i++)
            if (targets[i] == 0)
                if (predictions[i] == 0.0) a++;
                else b++;
            else
                if (predictions[i] == 0.0) c++;
                else d++;
            
        return new int[]{a, b, c, d};
    }
    
    private static double[][] sample(double[][] dataset, int n) {
        double[][] samples = new double[n][dataset[0].length];
        
        // step one: shuffle the dataset
        List<double[]> list = Arrays.asList(dataset);
        Collections.shuffle(list);
        dataset = list.toArray(new double[0][0]);
        
        // step two: assign values to sample array
        for (int i = 0; i < samples.length; i++)
            System.arraycopy(dataset[i], 0, samples[i], 0, samples[i].length);
        
        return samples;
    }
    
    static int factorial(int n) {
        return (n == 1 || n == 0) ? 1 : n*factorial(n - 1);
    }
    
    private static int computeR(Person x, Person y, Person z) {
        // R(x, y, z) = (N(x) & N(z) & N(y))
        boolean isNormal = x.getNormal() == 1 && y.getNormal() == 1 && z.getNormal() == 1;
        
        if (isNormal)
            return 1;
        else
            return 0;
    }
    
    private static int computeA2(Person x, Person y, Person z) {
        // A(x, y, z) = (H(x, y) & H(y, z) & W(x, y) & W(y, z)
        return 0;
    }
    
    private static int computeA1(Person x, Person y, Person z) {
        // A(x, y, z) = (H(x)>H(y)>H(z)) & (W(x)>W(y)>W(z))
        boolean height = x.getHeight() > y.getHeight() && y.getHeight() > z.getHeight();
        boolean weight = x.getWeight() > y.getWeight() && y.getWeight() > z.getWeight();
        
        if (height && weight)
            return 1;
        else
            return 0;     
    }
    
    private static List<Integer[]> execFOL(Person[] objects, int form) {
        List<Integer[]> predictions = new ArrayList<>();
        List<Integer> predA = new ArrayList<>();
        List<Integer> predR = new ArrayList<>();
        
        for (int i = 0; i < objects.length; i++) {
            for (int j = 0; j < objects.length; j++) {
                for (int k = 0; k < objects.length; k++) {
                    if (objects[i] != objects[j] && objects[i] != objects[k] && objects[j] != objects[k]) {
                        if (form == 1) predA.add(computeA1(objects[i], objects[j], objects[k]));
                        //else if (form == 2) predA.add(computeA2(objects[i], objects[j], objects[k]));
                        else System.out.println("Invalid Form Number");
                        predR.add(computeR(objects[i], objects[j], objects[k]));
                    }
                }
            }
        }
        
        Integer[] As = new Integer[predA.size()];
        Integer[] Rs = new Integer[predR.size()];
        
        predictions.add(predA.toArray(As));
        predictions.add(predR.toArray(Rs));
        
        return predictions;
    }

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        String fileName = "data/weight-height.csv";
        String[][] rawData = loadData(fileName);
        double[][] dataset = toDouble(removeHeaders(rawData));
        
        int numObjects = 4;
        
        // get random samples
        double[][] samples = sample(dataset, numObjects);
        
        // create Person objects
        Person[] objects = new Person[numObjects];
        
        for (int i = 0; i < samples.length; i++)
            objects[i] = new Person(samples[i][0], samples[i][1], (int) samples[i][2]);
        
        // compute results
        List<Integer[]> formOneResults = execFOL(objects, 1);
        Integer[] As = formOneResults.get(0);
        Integer[] Rs = formOneResults.get(1);
        
        printArray(As);
        printArray(Rs);
        
        
        //List<Integer[]> formTwoResults = execFOL(objects, 2);
        
        // output confusion matrices
        

    }
    
}
